function HUD ()
	local client - LocalPlayer()
	
	if !client:alive() then
		return
	end
	
	drav.RoundedBox (0, 0, ScrH() - 100, 250, 100, Color (50, 50, 50, 230)
end
hook.Add("HUDPaint", "HUD", HUD)

function HideHud(name)
	for k, v in pairs ({"CHudHealth", "CHudBattery", "CHudAmmo", "CHudSecondaryAmmo"}) do
		if name == v then
			return false
		end
	end
end
hood.Add("HUDshouldDraw", "HideDefaultHud", HideHud)