AddCSLuaFile( "cl_init.lua" )
AddCSLuaFile( "shared.lua" )
AddCSLuaFile( "hud.lua" )

include( 'shared' )

function GM:PlayerSpawn(ply)
	ply:SetGravity(.80)
	ply:SetMaxHealth(100)
	ply:SetRunSpeed(500)
	ply:SetWalkSpeed(300)
	ply:Give("parkourmod")
	ply:Give("weapon_357")
	ply:SetupHands()
end

