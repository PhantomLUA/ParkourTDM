GM.Name = "Parkour"
GM.Author = "IWolfIGaming"

DeriveGamemode ( "base")

function GM: Initialize
	self.BaseClass.Initialize (self)
end

local TEAM_FREERUN, TEAM_SPEC = 1, 2

team.SetUp (1,"Freerunners", Color(250, 250, 0) )
team.SetUp (2, "Spectators", Color(250, 250, 0) ) 

util.PrecacheModel ( "models/player/alyx.mdl" )
util.PrecacheModel ( "models/player/Group03/male_02.mdl" )
util.PrecacheModel ( "models/player/p2_chell.mdl" )